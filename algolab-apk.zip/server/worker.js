// Servidor opcional para el Tutor IA (Cloudflare Workers). Guarda tu clave como secreto ANTHROPIC_API_KEY.
export default {
  async fetch(req, env) {
    const cors = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,OPTIONS'};
    if (req.method === 'OPTIONS') return new Response(null, {headers: cors});
    const {prompt, json} = await req.json();
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {'content-type':'application/json','x-api-key':env.ANTHROPIC_API_KEY,'anthropic-version':'2023-06-01'},
      body: JSON.stringify({model:'claude-haiku-5-5', max_tokens: json ? 1000 : 600, messages:[{role:'user', content:String(prompt).slice(0,6000)}]})
    });
    const d = await r.json();
    const text = (d.content || []).map(c => c.text || '').join('');
    return new Response(JSON.stringify({text}), {headers: {...cors, 'content-type':'application/json'}});
  }
};
