# AlgoLab (APK)

## Compilar el APK con GitHub (sin PC ni Android Studio)
1. Crea un repositorio nuevo en GitHub.
2. Sube TODO el contenido de esta carpeta (arrastra los archivos y carpetas). Verifica que exista `.github/workflows/apk.yml`.
3. Ve a la pestaña **Actions** y espera a que termine "Build APK" (5-10 min). Si no arranca, entra al flujo y pulsa **Run workflow**.
4. Abre la ejecución terminada, baja **AlgoLab-apk** (zip), descomprime e instala `app-debug.apk` en tu celular (permite instalar apps desconocidas).

## Tutor IA (opcional)
1. Crea un Worker en Cloudflare con `server/worker.js` y guarda tu clave como secreto `ANTHROPIC_API_KEY`.
2. En `www/index.html` pon la URL del Worker en `const AI_URL='';`.
3. Cualquiera con la URL podría usar tu clave: ponle un límite de uso antes de compartir la app.

Sin servidor, todo funciona menos el Tutor IA y los problemas generados por IA.
